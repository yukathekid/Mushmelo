const Discord = require("discord.js"); 

module.exports = {
  name: 'serverinfo',
  description: 'Mostra as informações do servidor',
  aliases: ['si'],
  category: 'Informações',
  run: async (client, message, args) => {

  const { info, insignia } = client.emoji;  

  let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;	
  
  let use = message.guild.member(user);  
  const joinedDate = user.joinedAt;
  const entrouDate = formatDate(joinedDate);
  const createdDate = message.guild.createdAt;
  const criouDate = formatDate(createdDate);
  
  let categorias = message.guild.channels.cache.filter(chan => chan.type === 'category').size;
  let canalVoz = message.guild.channels.cache.filter(chan => chan.type === 'voice').size;
  let canalTexto = message.guild.channels.cache.filter(chan => chan.type === 'text').size;
  
  
  const serverembed = new Discord.MessageEmbed() 
    .setColor(`${user.displayHexColor || '#000000'}`)
    .setTitle(`${message.guild.name}`)
    .setThumbnail(message.guild.iconURL({dynamic: true}))
    .setImage("https:\/\/media.discordapp.net/attachments/874298355369525289/1234125696729747457/20240428_094607.jpg?ex=662f989f&is=662e471f&hm=9ac7458d6f14514bb8fbece6da35d530633ed6407ec211276d5b154b57bcb1df&")
    .addField(`${info.user.name} Apelido no Servidor`, use.nickname || 'Sem apelido')
    .addField(`${info.id.name} ID do Servidor`, message.guild.id, )    
    .addField(`${info.owner.name} Owner `, `${message.guild.owner.user} (${message.guild.ownerID})`)    
    .addField(`${info.data.name} Servidor criado em`, `${criouDate}`)     
    .addField(`${info.user.name} Membros`, `${(message.guild.memberCount) - (message.guild.members.cache.filter(member => member.user.bot).size)}`)
    .addField(`${info.category.name} Categorias \( ${categorias} \)`, `${info.text.name} **Texto:** ${canalTexto}\n${info.voice.name} **Voz:** ${canalVoz}`)
    .addField(`${info.data.name} Entrou no servidor em`, `${entrouDate}`) 

      message.inlineReply(serverembed);
            
  }
}

function formatDate(date) {
  const timestamp = Math.floor(date / 1000); // Converte a data para um timestamp UNIX
  return `<t:${timestamp}:f> (<t:${timestamp}:R>)`; // Formata a data no formato desejado
}


 
