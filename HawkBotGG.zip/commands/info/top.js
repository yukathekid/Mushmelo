const Discord = require('discord.js');
const axios = require('axios');
// Função para calcular o nível com base na quantidade de XP
function calculateLevel(xp) {
  const level = Math.floor(Math.sqrt(xp / 1000));
  return level;
}

module.exports = {
  name: 'top',
  aliases: ['rank'],
  description: 'Veja o rank de xp ou bucks do servidor.',
  usage: ['top bucks', 'top xp'],
  category: 'Info',
  run: async (client, message, args) => {
  
  if (args[0] === 'bucks') {
  try {
    const use = message.guild.member(message.author);

    const levelTOP = await client.database.users.find({ idS: process.env.GUILD_ID, coins: { $gte: 1}})
      .sort({ coins: -1 });

    const usersPerPage = 10;
    const totalPages = Math.ceil(levelTOP.length / usersPerPage || 1);
    let targetPage = args[1] || 1;
    targetPage = parseInt(targetPage);

    if (targetPage < 1) {
      targetPage = 1;
    } else if (targetPage > totalPages) {
      targetPage = totalPages;
    }

    const startIndex = (targetPage - 1) * usersPerPage;
    const endIndex = startIndex + usersPerPage;
    const pageUsers = levelTOP.slice(startIndex, endIndex);

    const topEmojis = ['🥇', '🥈', '🥉'];
    const authorData = levelTOP.find(data => data.idU === message.author.id);

    const e = new Discord.MessageEmbed()
      .setAuthor(`Top 10 usuários mais ricos em ${message.guild.name}`)
      .setColor("#4CAAFF");

    for (let iii = 0; iii < pageUsers.length; iii++) {
      const user = await message.guild.members.fetch(pageUsers[iii].idU);

      const currentUserData = pageUsers[iii];
    const headers = {
    'Authorization': `Bot ${process.env.TOKEN}`,
    };
    
    let globalName = '';
    const response = await axios.get(`https:\/\/discord.com/api/v10/users/${currentUserData.idU}`, { headers });        
    
    if (response.status === 200) {
        const userData = response.data;
        globalName = userData.global_name;
        //console.log('Nome global do usuário:', userName); // Adicione este log
        } 
        
    let displayName = globalName || currentUserData.username;   
      
      
      let positionEmoji = '';

      if (iii < 3) {
        positionEmoji = topEmojis[iii];
      } else {
        positionEmoji = `**${startIndex + iii + 1}.**`;
      }

      const formato = {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      };

      const formatBucks = pageUsers[iii].coins.toLocaleString('pt-BR', formato);

      e.addField(`${positionEmoji} ${displayName}`, `‎ ‎‎ ‎ ↳ ${client.emoji.economy.coins.name} **[${formatBucks}](https:\/\/drasilcord.rf.gd/) Bucks**`);

      // Se for o primeiro colocado, define a foto de perfil como thumbnail
      if (iii === 0) {
        const avatarURL = user.user.displayAvatarURL({ dynamic: true, size: 256 });
        e.setThumbnail(avatarURL);
      }
    }

    if (authorData) {
      e.setFooter(`Sua posição: ${levelTOP.indexOf(authorData) + 1}° com ${authorData.coins} Bucks.`);
    }

    return message.inlineReply(`Página **${targetPage}** de **${totalPages}**`, e);
  } catch (error) {
    console.error('Erro ao processar o comando de top Bucks:', error);
    message.inlineReply('Ocorreu um erro ao processar o comando de top Bucks.');
  }
}
    // ==================== //
    if(args[0] === "xp") {
    try {
    let use = message.guild.member(message.author);
    
    let levelTOP = await client.database.users.find({ idS: process.env.GUILD_ID, 'exp.xp': { $gte: 1 }}).sort({'exp.xp': -1});
    
    const usersPerPage = 10;
    const totalPages = Math.ceil(levelTOP.length / usersPerPage || 1);
    let targetPage = args[1] || 1;
    targetPage = parseInt(targetPage);

    if (targetPage < 1) {
      targetPage = 1;
    } else if (targetPage > totalPages) {
      targetPage = totalPages;
    }
    
    const startIndex = (targetPage - 1) * usersPerPage;
    const endIndex = startIndex + usersPerPage;
    const pageUsers = levelTOP.slice(startIndex, endIndex);

    const topEmojis = ['🥇', '🥈', '🥉'];
    const authorId = message.author.id;
    const authorData = levelTOP.find(data => data.idU === authorId);
    
    const e = new Discord.MessageEmbed()
    .setAuthor(`Classificação de experiência ${message.guild.name}`)
    .setColor("#4CAAFF")
    
    for (let iii = 0; iii < pageUsers.length; iii++) {
    const user = await message.guild.members.fetch(pageUsers[iii].idU);
    
    const currentUserData = pageUsers[iii];
    const headers = {
    'Authorization': `Bot ${process.env.TOKEN}`,
    };
    
    let globalName = '';
    const response = await axios.get(`https:\/\/discord.com/api/v10/users/${currentUserData.idU}`, { headers });        
    
    if (response.status === 200) {
        const userData = response.data;
        globalName = userData.global_name;
        //console.log('Nome global do usuário:', userName); // Adicione este log
        } 
        
    let displayName = globalName || currentUserData.username;   
  
    let positionEmoji = '';
    if (iii < 3 ) {
    positionEmoji = topEmojis[iii];
    } else {
    positionEmoji = `**${startIndex + iii + 1}.**`;
    }
    
    const formato = {
        minimumFractionDigits: 1,
        maximumFractionDigits: 1,
      };
    
    const exp = pageUsers[iii].exp.xp;
    let formatXP;
    
    if(exp <= 1000) {
        formatXP = exp.toLocaleString('pt-BR', {maximumFractionDigits: 0}).replace(',', '.');
    } else {
        formatXP = exp.toLocaleString('pt-BR', formato).replace(',', '.');
    }
    
    // Calcula o nível do usuário
    const userLevel = pageUsers[iii].exp.level;
    
    e.addField(`${positionEmoji} ${displayName}`, ` ‎‎ ‎ ↳ ‎\`LV${userLevel}\` ✨ **[${formatXP}](https:\/\/animespunch.com.br)** XP`);
    
    // Se for o primeiro colocado, define a foto de perfil como thumbnail
    if (iii === 0) {
    const avatarURL = user.user.displayAvatarURL({ format: 'png', dynamic: true});
    e.setThumbnail(avatarURL);
      }
    }
    
    if (authorData) {
    // Calcula o nível do autor
    const authorLevel = authorData.exp.level;
    
    e.setFooter(`Sua posição: ${levelTOP.indexOf(authorData) + 1}° ${authorData.exp.xp} com XP`);
    }
    
    return message.inlineReply(`Página **${targetPage}** de **${totalPages}**`, e);
    
     } catch (error) {
    console.error('Erro ao processar o comando de top Bucks:', error);
    message.inlineReply('Ocorreu um erro ao processar o comando de top.');
      } 
    }//top xp
    
    
  },
};
