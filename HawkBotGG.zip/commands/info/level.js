const Discord = require('discord.js');

module.exports = {
  name: 'level',
  description: 'Veja seu level, posição e próximo cargo no servidor.',
  aliases: ['nivel'],
  category: 'Info',
  run: async (client, message, args) => {
    try {    
      
      let targetUser = message.mentions.members.first() || message.member;
      
      const targetUserData = await client.database.users.findOne({ idU: targetUser.id, idS: process.env.GUILD_ID});

      if (!targetUserData) {
        message.inlineReply('Usuário não encontrado no banco de dados.');
        return;
      }

      const recompensas = client.utils.rolesexp;
      const userXP = targetUserData ? targetUserData.exp.xp : 0;
      const userLevel = targetUserData ? targetUserData.exp.level : 0;

      let xpProximoNivel = (userLevel + 1) * 1000;

      let xpNecessario = xpProximoNivel - userXP;

      let userPosition = '';
      if (userXP > 0) {
      const userList = await client.database.users.find({ guildId: process.env.GUILD_ID})
        .sort({ 'exp.xp': -1 })
        .select({ idU: 1 });
        userPosition = userList.findIndex((userData) => userData.idU === targetUser.id) + 1;
      }

      const valorxp = userXP;
      const xpFormatado = valorxp.toLocaleString('pt-BR');
      
      const valorlevel = userLevel;
      const levelFormatado = valorlevel.toLocaleString('pt-BR');
      
      const valorXpNess = xpNecessario;
      const xpNessFormatado = valorXpNess.toLocaleString('pt-BR');

      const prxNivel = userLevel + 1;
      let proximaRecompensa = '';
      let nivelNess = '';

      for (let nomeRecompensa in recompensas) {
        const recompensa = recompensas[nomeRecompensa];

        if (prxNivel < recompensa.nivel) {
          proximaRecompensa = recompensa.role;
          nivelNess = recompensa.nivel;
          break;
        }
      }

      const embed = new Discord.MessageEmbed()
        .setAuthor(`Nível de ${targetUser.user.username}`, targetUser.user.avatarURL({ dynamic: true }))
        .addField(`\`⭐\` » Nível atual :`, `‎ ‎ ‎ ↳ ${levelFormatado}`)
        .addField(`\`🧫\` » XP atual :`, `‎ ‎ ‎ ↳ ${xpFormatado}`);

      if (userPosition > 0) {
        embed.addField(`\`🏆\` » Colocação :`, `#${userPosition}`);
      }

      embed.addField(`\`🆙\` » XP necessário para o próximo nível \[ **${userLevel + 1}** \] : `, `‎ ‎ ‎ ↳ ${xpNessFormatado}XP`);

      const nextGift = nivelNess * 1000 + xpNecessario - xpProximoNivel;
      const giftNext = nextGift.toLocaleString('pt-br');

      const isGive = proximaRecompensa;
      const yeGive = isGive ? `‎ ‎ ‎Ganhe +${giftNext} XP e receba ${proximaRecompensa}` : 'Você já pegou todas as recompensas disponíveis no momento.';
      const isNivel = nivelNess;
      const yeNivel = isNivel ? `\[ Nível ${nivelNess} \]` : '';

      embed.addField(`\`🎁\` » Próxima recompensa : ${yeNivel}`, `${yeGive}`);

      message.inlineReply(embed);
    } catch (error) {
      console.error('Erro ao buscar dados do usuário:', error);
      message.inlineReply('Ocorreu um erro ao buscar os dados do usuário.');
    }
  },
};
