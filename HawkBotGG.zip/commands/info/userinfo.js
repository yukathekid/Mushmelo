const { MessageEmbed } = require('discord.js');
module.exports = {
    name: 'userinfo',
    description: 'Vejas suas informações ou de oitros usuários.',
    aliases: ['ui'],
    usage: 'userinfo @user ou userID',
    category: 'Informações',
    run: async (client, message, args) => {
    const { info, insignia, economy, hypesquad, panda } = client.emoji;
    const member = message.mentions.members.first() || message.member || client.users.cache.get(args[0]) || message.author;
    const serverOwnerID = message.guild.ownerID;



    const username = member.user.tag; // Obtém o nome de usuário do autor
    const regex = /^[^\d#]+\#\d{4}$/; // Esta regex verifica se não há dígitos ou # antes do #0000
    const hasValidUsername = regex.test(username);
    const isPomelo = hasValidUsername;
    const yePomelo = isPomelo ? '' : ` ${insignia.pomelo.name} `; // Define uma mensagem com base na verificação

      
    let use = message.guild.member(member);
    const membro = member.user.id; // Obtém o GuildMember do autor da mensagem no servidor atual

    const isServerOwner = member.id === serverOwnerID; // Verifica se o membro é o dono do servidor
    const ownerMe = isServerOwner ? ` ${info.owner.name} ` : ' '; // Define o emoji com base na condição
    const isBot = member.user.bot;
    const noBot = isBot ? 'sim' : 'não';
    const veryName = isBot ? 'do Bot' : 'do usuário';
    const name = isBot ? member.user.tag : member.user.username;

    const nickName = name;
       
    const roles = member.roles.cache
            .sort((a, b) => b.position - a.position)
            .map(role => role.toString())
            .slice(0, -1);
      
    const flags = {
    DISCORD_EMPLOYEE: 'Empregado do discord',
    DISCORD_PARTNER: 'Parceiro do discord',
    BUGHUNTER_LEVEL_1: 'Bug Hunter (Level 1)',
    BUGHUNTER_LEVEL_2: 'Bug Hunter (Level 2)',
    HYPESQUAD_EVENTS: `HyperSquad Events`,
    HOUSE_BRAVERY: `${hypesquad.bravery.name}`,
    HOUSE_BRILLIANCE: `${hypesquad.brilliance.name}`,
    HOUSE_BALANCE: `${hypesquad.balance.name}`,
    EARLY_SUPPORTER: 'Apoiante inicial',
    TEAM_USER: 'Usuário da equipe',
    SYSTEM: 'Sistema',
    VERIFIED_BOT: `${insignia.bot1.name}${insignia.bot2.name}`,
    BOT: 'Bot',
    VERIFIED_DEVELOPER: 'Desenvolvedor de bot verificado'
}
    const userFlags = member.user.flags.toArray();
    const flgs = userFlags.length ? userFlags.map(flag => flags[flag]).join(', ') : ''

    const joinedDate = member.joinedAt;
    const createdDate = member.user.createdAt;
           
    const entrouDate = formatDate(joinedDate);
    const criouDate = formatDate(createdDate);

      
        const embed = new MessageEmbed()
          .setTitle(`${nickName} ${ownerMe}${flgs}${yePomelo}`)
          .setThumbnail(member.user.displayAvatarURL({ dynamic: true}))
          .setColor(member.displayHexColor || 'BLACK')
          .addField(`${info.user.name} Nome ${veryName}`, name)
          .addField(`${info.id.name} ID do Discord`, member.user.id)
          .addField(`${info['@'].name} Menção`, member.user)
          .addField(`${info.bot.name} Bot`, noBot)
          .addField(`${info.role.name} Maior cargo`, `${member.roles.highest.id === message.guild.id ? 'Nenhum' : member.roles.highest}`)
          .addField(`${info.data.name} Entrou no discord em`, `${criouDate}`)
          .addField(`${info.data.name} Entrou no servidor em`, `${entrouDate}`)
          
        return message.inlineReply(embed);

    }

}

function formatDate(date) {
  const timestamp = Math.floor(date / 1000); // Converte a data para um timestamp UNIX
  return `<t:${timestamp}:f> (<t:${timestamp}:R>)`; // Formata a data no formato desejado
}
