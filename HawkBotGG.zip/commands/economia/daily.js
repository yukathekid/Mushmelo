const { Discord, MessageEmbed } = require('discord.js');
module.exports = {
    name: 'daily',
    aliases: ['day'],
    category: 'Economia',
    description: 'Resgate sua recompensa diária',
    run: async (client, message, args) => {
        const user = message.author;
        const dbConnect = await client.database.users.findOne({ idU: message.author.id, idS: message.guild.id });

        if (!dbConnect) {
            console.error('Usuário não encontrado no banco de dados.');
            return;
        }

        const hasVip = dbConnect.premium.hasVip;
        const cooldowns = dbConnect.cooldowns.daily;
        const currentTime = Date.now();
        const currentUpdate = cooldowns.ms - (currentTime - cooldowns.timer);

        if (cooldowns.timer && currentTime - cooldowns.timer < cooldowns.ms) {
            const timeStamp = `${parseInt(new Date(currentTime + currentUpdate).getTime() / 1000)}`;
            message.lineReply(`:alarm_clock: Você já resgatou sua recompensa diária.\nAguarde até <t:${timeStamp}:F> (<t:${timeStamp}:R>).`);
            return;
        }

        const amount = Math.floor(Math.random() * (3000 - 100 + 1) ) + 100;
        const bonus = hasVip ? amount * 0.10 : 0;
        const totalAmount = amount + bonus;
        const bucks = client.utils.toAbrev(totalAmount);
        client.transactions.register(process.env.GUILD_ID, message.author.id, 'daily', bucks)

        dbConnect.coins += totalAmount;
        dbConnect.cooldowns.daily.timer = currentTime;
        await dbConnect.save();

        message.lineReplyNoMention(`# Recompensa diária\nVocê coletou ${client.emoji.economy.coins.name} **${bucks} Bucks** na sua recompensa diária!\n- Saiba como usar seus **Bucks** em \`${process.env.PREFIX}info bucks\``);
    },
};
