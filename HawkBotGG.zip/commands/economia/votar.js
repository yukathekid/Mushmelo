const Discord = require('discord.js');
module.exports = {
  name: 'votar',
  description: 'Vote e ganhe uma recompensa!',
  aliases: ['vote'],
  category: 'Economia',
  run: async (client, message, args) => {
    let user = message.author;
    const membroDB = await client.database.users.findOne({idU: user.id, idS: process.env.GUILD_ID});
    
    let cooldownTime = membroDB.cooldowns.vote.ms;
    let author = membroDB.cooldowns.vote.timer;
    const tempoAtual = Date.now();
    const tempoAtualizado = cooldownTime - (tempoAtual - author);

    if (author && tempoAtual - author < cooldownTime) {
      const timeStamp = `${parseInt(new Date(tempoAtual + tempoAtualizado).getTime() / 1000)}`;
      message.inlineReply(`Você já votou recentemente. Volte <t:${timeStamp}:t> \(<t:${timeStamp}:R>\) para votar novamente.`);
    } else {      
        message.lineReplyNoMention(`> ## Vote no ${message.guild.name} e receba recompensas ao votar.\n> Veja todas as vantagens disponíveis ao votar:\n> - Receba o carago <@&1198628015349960704>\n> - Permissão de **Anexar arquivos**.\n> - Permissão de **Inserir links**.\n> - Ganhe até 5000 Bucks de forma aleatória.\n> - Cor exclusiva de nickname.\n> - Emblema exclusivo no nickname: embreve.\n\n- Nosso sistema de voto está disponível a cada **6h**.\n- Votar: [Click aqui para votar](https:\/\/discords.com/servers/950986486516441088/upvote)`);      
    }
  },
};
