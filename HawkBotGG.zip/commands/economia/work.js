const Discord = require('discord.js');
module.exports = {
    name: 'work',
    aliases: ['trabalhar', 'w'],
    category: 'Economia',
    run: async (client, message, args) => {
        const user = message.author;
        const dbConnect = await client.database.users.findOne({idU: user.id, idS: process.env.GUILD_ID});
        
        if (!dbConnect) {
            console.error('Usuário não encontrado no banco de dados.');
            return;
        }
        const { economy }= client.emoji;
        const hasVip = dbConnect.premium.hasVip;
        const cooldowns = dbConnect.cooldowns.work;
        const currentTime = Date.now();
        const currentUpdate = cooldowns.ms - (currentTime - cooldowns.timer);

        if (cooldowns.timer && currentTime - cooldowns.timer < cooldowns.ms) {
            const timeStamp = `${parseInt(new Date(currentTime + currentUpdate).getTime() / 1000)}`;
            message.lineReply(`:alarm_clock: Você já realizou um trabalho e necessita descansar um pouco. Volte <t:${timeStamp}:t> (<t:${timeStamp}:R>) para trabalhar novamente.`)
            
        } else {
        const random = Math.random();
        const chanceErro = hasVip ? 0 : 0.10;
      
        if(random < chanceErro) {
            message.lineReply(`Infelizmente você não fez um ótimo trabalho e acabou sendo despedido\(a\) da sua função.\n\nNão fique desanimado(\a\) tente novamente mais tarde em um novo trabalho.`)
        } else {
        
        const trabalho = client.utils.work();
        const amount = Math.floor(Math.random() * (1000 - 100 + 1)) + 100;
        dbConnect.coins += amount
        await dbConnect.save();
        
        const saldoConta = client.utils.toAbrev(dbConnect.coins);
        const win = client.utils.toAbrev(amount);
        
        client.transactions.register(process.env.GUILD_ID, message.author.id, 'work', win);
        
        message.lineReplyNoMention(`# Trabalho concluído\nHoje você trabalhou como **${trabalho.name}** ${trabalho.emoji} e pelo seu ótimo trabalho você recebeu ${economy.coins.name} **${win} Bucks**.`)
                
           }
        
        dbConnect.cooldowns.work.timer = currentTime;
        await dbConnect.save();
        
        }
    },
};
