const Discord = require("discord.js");
module.exports = {
  name: "transacoes",
  aliases: ["trasactions"],
  category: "Economia",
  run: async (client, message, args) => {
    const mentionedUser = message.mentions.members.first() || message.author;
    const { economy, panda } = client.emoji;
    try {
      const user = await client.database.users.findOne({
        idU: mentionedUser.id,
        idS: process.env.GUILD_ID,
      });
      const transactions = user ? user.transactions : [];

      const itemsPerPage = 10;
      const totalPages = Math.max(
        Math.ceil(transactions.length / itemsPerPage),
        1
      );
      let currentPage = 1;

      const displayPage = () => {
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const transactionsToDisplay =
          transactions.slice(startIndex).reverse() || [];

        const isMention = mentionedUser.id !== message.author.id;
        const title = isMention
          ? `Transações de ${mentionedUser.user.username}`
          : "Suas Transações";
        const description = formatTransactions(transactionsToDisplay);

        const transactionsEmbed = new Discord.MessageEmbed()
          .setColor("#0099ff")
          .setTitle(
            `${panda.pandaCash.name} ${title} - Página ${currentPage}`
          )
          .setDescription(description || "Nenhuma transação encontrada")
          .setFooter(`Quantidade de Transações (${user.transactions.length})`)

        return transactionsEmbed;
      };

      const transactionsMessage = await message.lineReplyNoMention(displayPage());

      if (totalPages > 1) {
        await transactionsMessage.react("◀️");
        await transactionsMessage.react("▶️");

        const filter = (reaction, user) => {
          return (
            ["◀️", "▶️"].includes(reaction.emoji.name) &&
            user.id === message.author.id
          );
        };

        const collector = transactionsMessage.createReactionCollector(filter, {
          time: 60000,
        });

        collector.on("collect", (reaction) => {
          if (reaction.emoji.name === "◀️" && currentPage > 1) {
            currentPage--;
          } else if (reaction.emoji.name === "▶️" && currentPage < totalPages) {
            currentPage++;
          }

          reaction.users.remove(message.author).catch(console.error);
          transactionsMessage.edit(displayPage());
        });

        collector.on("end", () => {
          transactionsMessage.reactions.removeAll().catch(console.error);
        });
      }
    } catch (error) {
      console.error(error);
      message.reply("Ocorreu um erro ao recuperar as transações.");
    }
  },
};

// Função para formatar as transações para exibição
function formatTransactions(transactions) {
  return transactions
    .map((transaction) => {
      const date = new Date(transaction.date);
      const formattedDate = formatDate(date);

      const value = transaction.amount;
      const type = transaction.type;
      const otherUserName = transaction.otherUserName;

      let description = "";

      if (type === "Recebeu") {
        description = `${formattedDate} 💵 Recebeu ${value} Bucks de \`${otherUserName}\``;
      } else if (type === "Enviou") {
        description = `${formattedDate} 💸 Enviou ${value} Bucks para \`${otherUserName}\``;
      } else if (type === "daily") {
        description = `${formattedDate} 💵 Recebeu ${value} Bucks ao resgatar o daily.`;
      } else if (type === "work") {
        description = `${formattedDate} 💵 Recebeu ${value} Bucks após realizar um trabalho.`;
      } else if (type === "Ganhou") {
        description = `${formattedDate} 💵 Foi adicionado ${value} Bucks na sua conta.`;
      } else if (type === "Inatividade") {
        description = `${formattedDate} 💵 Perdeu ${value} Bucks por inatividade no servidor.`;
      } else if (type === "votar") {
        description = `${formattedDate} 💵 Recebeu ${value} Bucks ao votar no servidor \`${otherUserName}\`.`;
      }

      return description;
    })
    .join("\n");
}

function formatDate(data) {
  const timestamp = Math.floor(data.getTime() / 1000);
  return `[ <t:${timestamp}:d> <t:${timestamp}:t> - <t:${timestamp}:R> ]`;
}