const Discord = require('discord.js');

module.exports = {
    name: 'cooldowns',
    description: 'Ver o tempo de espera de um comando.',
    aliases: ['cd', 'timers'],
    category: 'Economia',
    run: async (client, message, args) => {
    
    const usuario = message.author;
    const prefix = process.env.PREFIX;
    const membroDB = await client.database.users.findOne({idU: usuario.id, idS: process.env.GUILD_ID});
    const cooldowns = membroDB.cooldowns;
    const embed = new Discord.MessageEmbed()
      .setColor('#0099ff')
      .setAuthor(`Seus lembretes`, message.author.displayAvatarURL({ dynamic: true }))

    const commandMessages = {
      daily: {
        nome: 'Daily',
        available: `\n‎ ‎ ‎ ↳ \`Use ${prefix}daily para coletar.\``,
        cooldowns: cooldowns.daily.ms,
        emoji: '📅',
        timer: cooldowns.daily.timer,
      },
      work: {
        nome: 'Work',
        available: `\n‎ ‎ ‎ ↳ \`Use ${prefix}work para trabalhar.\``,
        cooldowns: cooldowns.work.ms,
        emoji: '💼',
        timer: cooldowns.work.timer,
      },
      votar: {
        nome: 'Votar',
        cooldowns: cooldowns.vote.ms,
        emoji: '🗳️',
        timer: cooldowns.vote.timer,
      },
    };

    let description = '';
    for (const cmd in commandMessages) {
      const cooldownTime = commandMessages[cmd].cooldowns;     
      const author = commandMessages[cmd].timer;
      const tempoAtual = Date.now();
      const tempoAtualizado = cooldownTime - (tempoAtual - author);

      if (author && tempoAtual - author < cooldownTime) {
        const timestamp = `<t:${Math.floor((tempoAtual + tempoAtualizado) / 1000)}:R>`;
        description += `\`\[${commandMessages[cmd].emoji}\]\` » ${uppercase(cmd)} ${timestamp}\n`;
      } else {
        description += `\`\[${commandMessages[cmd].emoji}\]\` » ${uppercase(cmd)} **Está pronto** ${client.emoji.utils.notification.name}\n‎ ‎ ‎ ‎ ‎ ↳ Use **[${prefix}${cmd}](https:\/\/animespunch.com.br)**\n`;
      }
    }

    embed.setDescription(description);
    message.lineReplyNoMention(embed);
  },
};

function uppercase(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

