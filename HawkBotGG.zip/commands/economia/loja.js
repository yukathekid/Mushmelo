const Discord = require('discord.js');

const ITEMS_PER_PAGE = 10;

module.exports = {
    name: 'loja',
    description: 'Mostra os itens da loja',
    run: async (client, message, args) => {
        let page = args[0] || 1;
        const offset = (page - 1) * ITEMS_PER_PAGE;

        try {
            const totalItems = await client.database.shop.countDocuments();
            const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

            const items = await client.database.shop.find().skip(offset).limit(ITEMS_PER_PAGE);
            let listItens = '';
            
            items.forEach(item => {
                listItens += `${item.emoji} **${item.name}** \`ID: ${item.id}\` - __[\`${client.utils.toAbrev(item.price)}\`](https:\/\/animespunch.com.br)__ ${client.emoji.economy.coins.name}\n${item.description}\n`;
            });
            
            const embed = new Discord.MessageEmbed()
                .setColor('#0099ff')
                .setTitle(`Loja de itens ${client.user.username}`)
                .setDescription(`Bem vindo(a) a minha loja u.U\nCompre usando: **[${process.env.PREFIX}loja buy \<id\>](https:\/\/animespunch.com.br)**`)
                .addField("Lista de itens", listItens)
                

            const msg = await message.lineReplyNoMention(`Página **${page}**`, embed);

            if (page > 1) await msg.react('⬅️');
            if (page < totalPages) await msg.react('➡️');

            const filter = (reaction, user) => ['⬅️', '➡️'].includes(reaction.emoji.name) && user.id === message.author.id;
            const collector = msg.createReactionCollector(filter, { time: 60000 });

            collector.on('collect', async (reaction, user) => {
                reaction.users.remove(user.id);

                if (reaction.emoji.name === '⬅️') {
                    page--;
                } else if (reaction.emoji.name === '➡️') {
                    page++;
                }

                await msg.reactions.removeAll();
                const newItems = await client.database.shop.find().skip((page - 1) * ITEMS_PER_PAGE).limit(ITEMS_PER_PAGE);
              
                let listItens = '';
            newItems.forEach(item => {
                listItens += `${item.emoji} **${item.name}** \`ID: ${item.id}\` - __[\`${client.utils.toAbrev(item.price)}\`](https:\/\/animespunch.com.br)__ ${client.emoji.economy.coins.name}\n${item.description}\n`;
                });
                
                const newEmbed = new Discord.MessageEmbed()
                    .setColor('#0099ff')
                    .setTitle(`Loja de itens ${client.user.username}`)
                    .setDescription(`Bem vindo(a) a minha loja u.U\nCompre usando: **[${process.env.PREFIX}loja buy \<id\>**](https:\/\/animespunch.com.br)**`)
                    .addField("Lista de itens", listItens)
                    
      
                await msg.edit(`Página **${page}**`, newEmbed);

                if (page > 1) await msg.react('⬅️');
                if (page < totalPages) await msg.react('➡️');
            });

            collector.on('end', () => {
                msg.reactions.removeAll();
            });
        } catch (err) {
            console.error(err);
            message.channel.send('Ocorreu um erro ao mostrar os itens da loja.');
        }
        
        
        
        if(args[0] === 'buy') {
            const item = args[1];
            
            if(isNaN(item) && !shop) {
                return message.lineReplyNoMention('Por favor forneça um id válido.')
            }
            
            const shop = await client.database.shop.findOne({id: item});
            if(!shop) {
                return message.lineReplyNoMention('O item não existe.')
           }
            
            const memberItem = await client.database.users.findOne({ idU: message.author.id });
           
           
            if(memberItem.inventory.some(invItem => invItem.id === shop.id)) {
    const existingItem = memberItem.inventory.find(invItem => invItem.id === shop.id);
           existingItem.size += 1;
          } else {
    memberItem.inventory.push({ name: shop.name, id: shop.id, size: 1, emoji: shop.emoji});
          }
            await memberItem.save();
           
           message.lineReplyNoMention(`Parábens! você comprou o item ${shop.id} ${shop.emoji} ${shop.name} com sucesso.`)
        }//buy
    },
};