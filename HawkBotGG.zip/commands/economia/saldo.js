const Discord = require('discord.js');

module.exports = {
  name: 'saldo',
  aliases: ['conta'],
  description: 'Veja a quantidade de Bucks que você ou um usuário possui.',
  usage: '@user',
  category: 'Economia',
  run: async (client, message, args) => {
    let membro = message.mentions.members.first();
    const guildID = process.env.GUILD_ID;
    let mentioned = '';
    let rank = '';

    if (!membro) {
      membro = message.member;
      mentioned = `Você possui`;
      rank = `Você`;
    } else {
      mentioned = `${membro} possui`;
      rank = 'Ele';
    }

    try {
      // Busca o usuário no MongoDB
      const user = await client.database.users.findOne({idU: membro.user.id, idS: guildID});

      if (!user) {
        return message.inlineReply('Usuário não encontrado no banco de dados.');
      }

      const saldo = user.coins || 0;
      const bucks = client.utils.toAbrev(saldo);

      const userList = await client.database.users.find({idS: guildID}).sort({ coins: -1 });
      const userPosition = userList.findIndex((userData) => userData.idU === membro.user.id) + 1;
      const memberPosition = userPosition ? userPosition : '?';

      message.lineReplyNoMention(`${client.emoji.panda.pandaCash.name} ${mentioned} ${client.emoji.economy.coins.name} **${bucks} Bucks**.\n${client.emoji.panda.pandaCool.name} ${rank} está em **${memberPosition}° no ranking de mais rico!** Veja o ranking completo em \`-top bucks\``);
      
    } catch (error) {
      console.error('Erro ao buscar saldo do usuário:', error);
      message.inlineReply('Ocorreu um erro ao buscar o saldo do usuário.');
    }
  },
};
