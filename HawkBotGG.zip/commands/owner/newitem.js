const Discord = require('discord.js');

module.exports = {
  name: 'newitem',
  run: async (client, message, args) => {
    // Mapear todos os emojis do servidor
    let emojiMap = {};
    let emojiID = {};
    client.guilds.cache.forEach(guild => {
      guild.emojis.cache.forEach(emoji => {
        emojiMap[emoji.name] = emoji.toString();
        emojiID[emoji.name] = emoji.id;
      });
    });

    // Iniciar a coleta de mensagens para obter o nome do item
    message.channel.send("Por favor, digite o nome do item:");

    const nameFilter = (response) => response.author.id === message.author.id;
    const nameCollector = new Discord.MessageCollector(message.channel, nameFilter, {
      max: 1,
      time: 60000,
    });

    nameCollector.on("collect", (nameMsg) => {
      const newItem = {};
       newItem.name = nameMsg.content;

      // Continuar com a coleta de mensagens para obter o valor do item
      nameMsg.channel.send("Por favor, digite o valor do item (um número):");

      const valueFilter = (response) => response.author.id === message.author.id;
      const valueCollector = new Discord.MessageCollector(message.channel, valueFilter, {
        max: 1,
        time: 60000,
      });

      valueCollector.on("collect", (valueMsg) => {
        const value = parseInt(valueMsg.content);

        if (isNaN(value)) {
          valueMsg.channel.send("Valor inválido. Por favor, digite um número.");
          return;
        }

        newItem.price = value;

        // Continuar com a coleta de mensagens para obter a descrição do item
        valueMsg.channel.send("Por favor, digite a descrição do item:");

        const descriptionFilter = (response) => response.author.id === message.author.id;
        const descriptionCollector = new Discord.MessageCollector(message.channel, descriptionFilter, {
          max: 1,
          time: 60000,
        });

        descriptionCollector.on("collect", async (descMsg) => {
          newItem.description = descMsg.content;

          // Continuar com a coleta de mensagens para obter o emoji do item
          descMsg.channel.send('Digite o nome do emoji personalizado para o item:');

          const emojiFilter = (response) => response.author.id === message.author.id;
          const emojiCollector = new Discord.MessageCollector(message.channel, emojiFilter, {
            max: 1,
            time: 60000,
          });

          emojiCollector.on('collect', async (emojiMsg) => {
            const emojiName = emojiMsg.content.trim();

            // Verificar se o emoji está no mapa
            const emoji = emojiMap[emojiName];

            if (!emoji) {
              emojiMsg.channel.send('Emoji não encontrado.');
              return;
            }

            newItem.emoji = emoji;

            // Gere um ID aleatório até que seja único
            do {
              newItem.id = Math.floor(Math.random() * 10000);
            } while (await client.database.shop.findOne({ id: newItem.id  }));

            // Adicionar o novo item à loja e salvar no MongoDB
            const shopSave = new client.database.shop({
                id: newItem.id,
                name: newItem.name,
                description: newItem.description,
                price: newItem.price,
                emoji: newItem.emoji,
            });

            await shopSave.save()
              .then(() => message.channel.send(`Item "${newItem.name}" adicionado à loja com ID ${newItem.id}.`))
              .catch(err => console.error(err));
          });
        });
      });
    });
  }
}