const Discord = require('discord.js');

module.exports = {
    name: 'manutencao',
    aliases: ['manu'],
    category: 'Owner',
    run: async (client, message, args) => {
        if (message.author.id !== process.env.OWNER_ID) {
            return message.inlineReply(`Você não possui permissão para executar esse comando.`);
        }

        const commandName = args.shift().toLowerCase();
        let reason = args[1];

        const command = client.commands.get(commandName) || client.commands.get(client.aliases.get(commandName));

        if (!command) return message.inlineReply(`O comando ${commandName} não existe.`);

        try {
            let cmdManu = await client.database.commands.findOne({ idC: command.name });

            if (!reason) {
                reason = cmdManu ? cmdManu.reason : '';
            }

            if (cmdManu && cmdManu.manutencao) {
                cmdManu.manutencao = false;
                cmdManu.reason = '';
                await cmdManu.save();
                return message.inlineReply(`Comando ${command.name} removido da manutenção.`);
            }

            cmdManu.manutencao = true;
            cmdManu.reason = reason;
            await cmdManu.save();
            message.inlineReply(`O comando ${command.name} entrou em modo de manutenção com sucesso.`);
        } catch (error) {
            console.error('Erro ao adicionar o comando à lista de manutenção:', error);
            message.inlineReply('Ocorreu um erro ao adicionar o comando à lista de manutenção.');
        }
    },
};