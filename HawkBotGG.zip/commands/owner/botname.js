const Discord = require('discord.js');

module.exports = {
  name: 'botname',
  description: 'Altera o nome do bot',
  category: 'Owner',
  run: async (client, message, args) => {
    if (message.author.id !== message.guild.ownerID) {
      return message.inlineReply('Apenas o dono pode alterar o nome do bot.');
    }

    if (!args.length) {
      return message.inlineReply('Por favor, forneça um novo nome para o bot.');
    }

    const newBotName = args.join(' ');

    if (newBotName.length > 32) {
      return message.inlineReply('O novo nome do bot não pode ter mais de 32 caracteres.');
    }

    try {
      client.user.setUsername(newBotName);
      message.channel.send(`Nome do bot alterado para: ${newBotName}`);
    } catch (error) {
      console.error('Erro ao alterar o nome do bot:', error);
      message.inlineReply('Ocorreu um erro ao alterar o nome do bot.');
    }
  },
};
