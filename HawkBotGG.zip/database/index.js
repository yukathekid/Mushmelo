const mongoose = require('mongoose');
const color = require('colors');
module.exports = {
  async database(client) {
    try {
      await mongoose.connect(process.env.DATABASE_CONNECT, {
      useFindAndModify: false,
      useNewUrlParser: true,
      useUnifiedTopology: true,          
      });  
      
      console.log(color.red('Banco de dado conectado com sucesso.'));
        
    } catch (err) {
       console.error(color.red(err.message));
    }
    
    
   },
};
