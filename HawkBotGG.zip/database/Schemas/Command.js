const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let CommandSchema = new Schema({
    idC: { type: String, unique: true},
    manutencao: { type: Boolean, default: false},
    reason: { type: String, default: "Motivo não especificado"}
});

let Command = mongoose.model('Command', CommandSchema);
module.exports = Command;
