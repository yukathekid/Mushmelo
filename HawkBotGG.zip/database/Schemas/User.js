const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let userSchema = new Schema({
  idU: { type: String, unique: true },
  idS: { type: String },
  username: { type: String },
  coins: { type: Number, default: 0 },
  transactions: { type: Array, default: [] },
  messageCount: { type: Number, default: 0 },
  cooldowns: {
     daily: {
        timer: { type: Date, default: null },
        ms: { type: Number, default: 86400000 },
        hasVip: { type: Number, default: 0 },
        },
     vote: { 
        timer: { type: Date, default: null },
        ms: { type: Number, default: 21600000 },
        },
     work: { 
        timer: { type: Date, default: null },
        ms: { type: Number, default: 3600000 },
        },
   },
  premium: {
        hasVip: { type: Boolean, default: false },
        roleVip: { type: String, default: null },
        data: { type: Date, default: null },
        idU: { type: String },      
   },
  exp: {
        xp: { type: Number, default: 0 },
        level: { type: Number, default: 0 },
   },
  inventory: [{
        name: { type: String},
        id: { type: Number, unique: true },
        size: { type: Number, default: 0 },
        emoji: { type: String }
   }],
});

module.exports = mongoose.model('Users', userSchema);
