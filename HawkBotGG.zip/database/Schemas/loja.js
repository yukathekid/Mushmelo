const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let shopSchema = new Schema({

        id: { type: Number, unique: true },
        name: { type: String},
        description: { type: String },
        price: { type: Number },
        emoji: { type: String }
 
});

module.exports = mongoose.model('Shop', shopSchema);