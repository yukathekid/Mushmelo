const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let ClientSchema = new Schema({
    idB: { type: String, unique: true },
    manutencao: { type: Boolean, default: false},
    reason: { type: String}
});

let Client = mongoose.model('Client', ClientSchema);
module.exports = Client;
