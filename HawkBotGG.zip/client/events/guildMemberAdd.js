// guildMemberAddEvent.js
module.exports = (client) => {
    client.on("guildMemberAdd", async (member) => {
         const guild = client.guilds.cache.get(process.env.GUILD_ID);
      
      if (!guild) {
        console.error(`O bot não está no servidor com o ID ${process.env.GUILD_ID}.`);
        return;
      }
      
      client.registerUser(guild);
          
    });
};