// messageEvent.js
const axios = require('axios');
module.exports = (client) => {
  client.on("message", async (message) => {
       const emoji = require('../../utils/Schemas/emojis')(client);
       const prefix = process.env.PREFIX;
       if(!prefix) return;
       if (message.author.bot) return;
       if (!message.content.startsWith(prefix)) return;
      
       const args = message.content.slice(prefix.length).trim().split(/ +/);
       const commandName = args.shift().toLowerCase();

    // Verificar se o comando existe
       const command = client.commands.get(commandName) || client.commands.get(client.aliases.get(commandName));       
    
    if (!command) return;
    
        const cmdManu = await client.database.commands.findOne({idC: command.name});
        
     if(cmdManu && cmdManu.manutencao) return message.inlineReply(`O comando ${command.name} está em manutenção.`);
    
       const userId = message.mentions.members.first() || message.member || client.users.cache.get(args[0]) || message.author;
       const headers = {
    'Authorization': `Bot ${process.env.TOKEN}`,
    };
    
    try {
        const response = await axios.get(`https:\/\/discord.com/api/v10/users/${userId.id}`, { headers });
        
        if (response.status === 200) {
        const userData = response.data;
        client.userName = userData.global_name;
        //console.log('Nome global do usuário:', userName); // Adicione este log
        } 
        
      command.run(client, message, args);
    } catch (error) {
        console.error(error);
        message.reply("> Ocorreu um erro ao executar o comando.\nEsse comando não existe.");
      }
         
   });
};