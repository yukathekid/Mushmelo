module.exports = (client) => {
    //Evento de voto no servidor
    client.on('guildMemberUpdate', async (oldMember, newMember) => {
       const membroDB = await client.database.users.findOne({idU: newMember.user.id, idS: process.env.GUILD_ID});
  
       const guild = newMember.guild;
       const roleID = '1198628015349960704';
       const money = Math.floor(Math.random() * (4000 - 500 + 1)) + 500;
  
 
       const moneyFormatado = client.utils.toAbrev(money);
  
  // Verifica se o cargo foi adicionado ao membro
    if (!oldMember.roles.cache.has(roleID) && newMember.roles.cache.has(roleID)) {    
   
     // Lógica para recompensar o usuário
    try {
  await newMember.send(`> ${newMember.user} obrigado por votar no ${newMember.guild.name}!\n> Sua recompensa: ${moneyFormatado} Bucks.\n> Divirta-se com suas novas vantagens no servidor!\n> Vote no servidor a cada \`6h\`.`);
  console.log('Mensagem enviada com sucesso para', newMember.user.username);
} catch (error) {
  // Erro ao enviar a mensagem
  if (error.code === 50007) {
    console.error('O usuário desativou as mensagens diretas ou bloqueou o bot.');
  } else {
    console.error('Erro ao enviar a mensagem:', error);
  }
}              
       //logs
      const logChannelID = '1013629834179641414';
      const priChat = guild.channels.cache.get(logChannelID);
    if (priChat) {
      priChat.send(`> O usuário ${newMember.user} acaba de votar no servidor.\n> Obrigado\(a\) por votar!`).then((msg) => {
          setTimeout(() => {
              msg.delete();
          }, 30000);
      });
    } else {
      console.error('Canal de log não encontrado.');
    }    
    
    membroDB.cooldowns.vote.timer = Date.now();
    membroDB.coins += money;
    await membroDB.save();
         
    
    registerTransaction(guild.id, newMember.id, 'votar', moneyFormatado, guild.id, guild.name)

    // Adicione mais lógica conforme necessário
    setTimeout(() => {
      const role = guild.roles.cache.get(roleID);
      newMember.roles.remove(role)
        .then(() => {
          console.log(`Cargo removido de ${newMember.user.username} após 6 horas.`);
        })
        .catch(error => {
          console.error('Erro ao remover o cargo:', error);
        });
    }, 21600000); // 6 horas em milissegundos
  }
  
  });
}