// readyEvent.js
const User = require('../../database/Schemas/User');
const Command = require('../../database/Schemas/Command');
const Client = require('../../database/Schemas/Client');
const loja = require('../../database/Schemas/loja');

module.exports = (client) => {
client.on("ready", async () => {
require('../Schemas/registerUser')(client);

        console.log(`O bot está online como ${client.user.tag}!`);
        
        const guild = client.guilds.cache.get(process.env.GUILD_ID);
        
     client.registerUser(guild);
     
     client.database = {
         users: User,
         clients: Client,
         commands: Command,
         shop: loja,         
     }
       
       require('../Schemas/registerCommands').registerCommands(client);
    });
};