module.exports = (client) => {
  async function registerTransaction(guildId, userId, type, amount, otherUserId, otherUserName) {
    try {
      const user = await client.database.users.findOne({ idU: userId, idS: guildId });

      if (user) {
        const transaction = { type, amount, otherUserId, otherUserName, date: new Date() };
        user.transactions.push(transaction);
        await user.save();
      } else {
        console.error('Usuário não encontrado ao registrar transação');
      }
    } catch (error) {
      console.error('Erro ao registrar transação:', error);
    }
  }

  client.transactions = {
    register: registerTransaction,
  };
};