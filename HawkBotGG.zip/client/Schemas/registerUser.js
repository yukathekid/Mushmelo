const color = require('colors');
module.exports = (client) => {
   async function register(guild) {
       const members = await guild.members.fetch()     
       for (const member of members.values()) {
       
         if(!member.user.bot) {
          const registerUser = await client.database.users.findOne({idU: member.user.id})
       
          if(!registerUser) { 
           const newUser = new client.database.users({
               idU: member.user.id,
               idS: process.env.GUILD_ID,
               username: member.user.username, 
           });//registerUser 
        
           try {
             await newUser.save();
             console.log(color.green(`${member.user.username} registrado!`)); 
           } catch (err) {
               if(err.code === 11000) {
                console.log(color.red(`Usuário ${member.user.username} já está registrado!`));  
               } else {
                   console.error(color.red(`Erro ao registrar usuário`, err));
               }//err.code          
           }//err          
          }//!registerUser
          
         }//!member.user.bot                
       }//for
       
       if(process.env.BOT_ID){
        const registerClient = await client.database.clients.findOne({idB: process.env.BOT_ID})
        
        if(!registerClient) {
         const newClient = new client.database.clients({
             idB: process.env.BOT_ID
         });
         
         try {
             await newClient.save();
             console.log(color.green(`Bot registrado!`));
         } catch (err) {
             if(err.code === 11000) {
              console.log(color.red(`Bot já está registrado!`));     
             } else {
                 console.error(color.red(`Erro ao registrar bot`, err));
             }
         }//try catch
        }//registerBot
       } else {
           console.log(color.yellow('ID não encontrado.'))
       }//ifbotid
   }
   
   client.registerUser = register;
};
