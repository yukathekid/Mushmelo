module.exports = {
 async exp(client) {
const level100RoleID = '1150541666906808392'; // Substitua pelo ID do cargo de nível 100.
const maxUsers = 1; // Define o limite máximo de usuários com o cargo.
const usersWithLevel100Role = new Set();

client.on("message", async (message) => {
  if(message.author.bot || !message.guild) return;
   const guildID = process.env.GUILD_ID;
   const prefix = process.env.PREFIX;
   const recompensas = client.utils.rolesexp;
  try {
    let userData = await client.database.users.findOne({idU: message.author.id, idS: guildID});

    if (!userData) {
      console.error('Erro ao obter/atualizar dados do usuário.');
      return;
    }
    const messageCount = userData.messageCount;
    
    if (!message.content.startsWith(prefix)) {
         userData.messageCount += 1;
         await userData.save();

      if (messageCount % 5 === 0) {
        let xpReward;
        if (client.user.id === '954619656721825842')
        xpReward = Math.floor(Math.random() * 11) + 10;
        let vip = userData.premium.hasVip;
        const xpToAdd = vip ? xpReward * 2 : xpReward;
        userData.exp.xp += xpToAdd;
        await userData.save();
        const { xp, level } = userData.exp;
        const level2 = level + 1;
        const xpNecessario = (level + 1) * 1000;      
    
       if (xp >= xpNecessario) {
        userData.exp.level += 1;
        await userData.save();
        const newLevel = userData.exp.level;

    // Remover os cargos de níveis inferiores ao novo nível
    for (let i = 1; i < newLevel; i++) {
        for (let nomeRecompensa in recompensas) {
            const recompensa = recompensas[nomeRecompensa];
            const roleData = recompensa.nivel[i];
            if (roleData && roleData.roleID) {
                const roleToRemove = message.guild.roles.cache.get(roleData.roleID);
            if(roleToRemove) {
          message.member.roles.remove(roleToRemove);
                }
            }
        }
    }
    
    // Adicionar o cargo correspondente ao novo nível
    for (let nomeRecompensa in recompensas) {
        const recompensa = recompensas[nomeRecompensa];
        const roleData = recompensa.nivel[newLevel];
        if (roleData && roleData.roleID) {
            const roleToGive = message.guild.roles.cache.get(roleData.roleID);
            if (roleToGive) {
                message.member.roles.add(roleToGive);
                message.channel.send(`> ${message.author} subiu para o nível ${newLevel} e recebeu o cargo ${roleToGive.name}!`);
                break;
            }
        } else {
            message.channel.send(`> ${message.author} subiu para o nível ${newLevel}!`);
            break;
        }
    }
}//if xp
       

        if (level2 > 0) {
          const member = message.guild.members.cache.get(message.author.id);
          const role = message.guild.roles.cache.get(level100RoleID);

          if (member && role && !member.roles.cache.has(level100RoleID)) {
            if (usersWithLevel100Role.size < maxUsers) {
              member.roles.add(role);
              usersWithLevel100Role.add(member.id);
            } else {
              message.channel.send(`O limite máximo de ${maxUsers} usuários com o cargo foi atingido.`);
            }
          }
          await userData.save();
        }
      }
    }
    
  } catch (error) {
    console.error('Erro ao processar XP e nível:', error);
    message.inlineReply('Ocorreu um erro ao processar XP e nível.');
  }
});

   },
};

