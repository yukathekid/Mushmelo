module.exports = {
    async registerCommands(client) {
        try {
            client.commands.forEach(async command => {
                const existingCommand = await client.database.commands.findOne({ idC: command.name });
                
                if (!existingCommand) {
                    const newCommand = new client.database.commands({ idC: command.name });
                    await newCommand.save();
                    console.log(`Comando '${command.name}' salvo no banco de dados.`);
                } else {
                    console.log(`Comando '${command.name}' não existe no banco de dados.`);
                }
            });
        } catch (error) {
            console.error('Erro ao salvar comandos no banco de dados:', error);
        }
    }
};