const { readdirSync } = require("fs");

module.exports = (client) => {
    const loadCommands = (dir) => {
        const commandFiles = readdirSync(`./commands/${dir}`).filter(file => file.endsWith('.js'));
       
        for (const file of commandFiles) {
            const command = require(`../commands/${dir}/${file}`);
            client.commands.set(command.name, command);
            if (command.aliases) {
                command.aliases.forEach(alias => {
                    client.aliases.set(alias, command.name);
                });
            }
        }
    };

    // Carregue os comandos de diretórios específicos
    ["economia", "owner", "info"].forEach(dir => loadCommands(dir));
};
