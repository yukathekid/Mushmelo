module.exports = {
    works() {
     const trabalhos = [
      { emoji: '🧑🏻‍💼', name: 'Garçom' },
      { emoji: '💈', name: 'Barbeiro' },
      { emoji: '🪚', name: 'Carpinteiro' },
      { emoji: '🧑🏻‍🚒', name: 'Bombeiro' },
      { emoji: '🗞️', name: 'Jornalista' },
      { emoji: '👮🏻', name: 'Policial' },
      { emoji: '👨🏻‍💼', name: 'Arquiteto' },
      { emoji: '👷🏻', name: 'Engenheiro' },
      { emoji: '⚖️', name: 'Advogado' },
      { emoji: '🩺', name: 'Médico' },  
    ]
    
   return trabalhos[Math.floor(Math.random() * trabalhos.length)];

    },
};
