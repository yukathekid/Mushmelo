module.exports = {
toAbrev(valor) {
    const formato = {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
      };
          
    return valor.toLocaleString('pt-BR', formato);
    }

}
