module.exports = (client) => {
  let emojiMap = {};
  let emojiID = {};
  client.guilds.cache.forEach(guild => {
    guild.emojis.cache.forEach(emoji => {
      emojiMap[emoji.name] = emoji.toString();
      emojiID[emoji.name] = emoji.id;
    });
  });
  
  client.emoji = {
    info: {
      owner: {
          name: emojiMap['sv_owner'],
          id: emojiID['sv_owner'],
      },
      user: {
          name: emojiMap['sv_user'],
          id: emojiID['sv_user'],
      },
      id: {
          name: emojiMap['sv_id'],
          id: emojiID['sv_id'],
      },
      '@': {
          name: emojiMap['sv_arroba'],
          id: emojiID['sv_arroba'],
      },
      bot: {
          name: emojiMap['sv_bot'],
          id: emojiID['sv_bot'],
      },
      role: {
          name: emojiMap['sv_role'],
          id: emojiID['sv_role'],
      },
      data: {
          name: emojiMap['sv_data'],
          id: emojiID['sv_data'],
      },
      category: {
          name: emojiMap['sv_categoria'],
          id: emojiID['sv_categoria'],
      },
      text: {
          name: emojiMap['sv_texto'],
          id: emojiID['sv_texto'],
      },
      voice: {
          name: emojiMap['sv_voz'],
          id: emojiID['sv_voz'],
      },
    },
    
    insignia: {
      pomelo: {
          name: emojiMap['sv_pomelo'],
          id: emojiID['sv_pomelo'],
      },
      bot1: {
          name: emojiMap['bot1'],
          id: emojiID['bot1'],
      },
      bot2: {
          name: emojiMap['bot2'],
          id: emojiID['bot2'],
      },
    },
    
    economy: {
      coins: { 
          name: emojiMap['bucks'],
          id: emojiID['bucks'],
      },
      gemas: {
          name: emojiMap['gemas'],
          id: emojiID['gemas'],
      },
      pepeBucks: {
          name: emojiMap['pepe_bucks'],
          id: emojiID['pepe_bucks'],
      },
      daily: {
          name: emojiMap['dailydc'],
          id: emojiID['dailydc'],
      },
    },
    
    hypesquad: {
      events: {
          name: emojiMap['hypesquad'],
          id: emojiID['hypesquad'],
      },
      balance: {
          name: emojiMap['hs_balance'],
          id: emojiID['hs_balance'],
      },
      bravery: {
          name: emojiMap['hs_bravery'],
          id: emojiID['hs_bravery'],
      },
      brilliance: {
          name: emojiMap['hs_brilliance'],
          id: emojiID['hs_brilliance'],
      },
    },
    
    panda: {
      pandaCash: {
          name: emojiMap['pandecodocash'],
          id: emojiID['pandecodocash'],
      },
      pandaCool: {
          name: emojiMap['panda_cool'],
          id: emojiID['panda_cool'],
      },
      pandaGift: {
          name: emojiMap['panda_gift'],
          id: emojiID['panda_gift'],
      },
      pandaCute: {
          name: emojiMap['panda_cute'],
          id: emojiID['panda_cute'],
      },
      pandaWorking: {
          name: emojiMap['panda_working'],
          id: emojiID['panda_working'],
      },
      pandaAnger: {
          name: emojiMap['panda_anger'],
          id: emojiID['panda_anger'],
      },
    },
    
    utils: {
      True: {
          name: emojiMap['sv_true'],
          id: emojiID['sv_true'],
      },
      False: {
          name: emojiMap['sv_false'],
          id: emojiID['sv_false'],
      },
      green: {
          name: emojiMap['greenCircle'],
          id: emojiID['greenCircle'],
      },
      yellow: {
          name: emojiMap['yellowCircle'],
          id: emojiID['yellowCircle'],
      },
      red: {
          name: emojiMap['redCircle'],
          id: emojiID['redCircle'],
      },
      notification: { 
          name: emojiMap['notificationgg'],
          id: emojiID['notificationgg'],
      },
    },
    
    server: {
      ban: {
          name: emojiMap['sv_ban'],
          id: emojiID['sv_ban'],
      },   
    }, 
    
  };
};