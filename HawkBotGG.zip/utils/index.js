const { toAbrev } = require('./Schemas/toAbrev');
const { works } = require('./Schemas/trabalhos');
const { recompensas } = require('./Schemas/rolesxp');
module.exports = {
    async utils(client) {   
        client.utils = {
            toAbrev: toAbrev,
            work: works,
            rolesexp: recompensas,
        }
        
    },
};