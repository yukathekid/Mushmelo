const Discord = require('discord.js')
const client = new Discord.Client();
const axios = require('axios');
const fs = require("fs");
const inline = require('./inline');
const express = require('express');
const app = express();
client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
require('dotenv').config();
require('discord-reply'); 
require('./utils/index').utils(client);
require('./database/index').database(client);
require('./client/Schemas/transactions')(client);
require('./client/Schemas/xp').exp(client);
const loadCommands = require('./handler/command');
loadCommands(client);

const eventFiles = fs.readdirSync('./client/events').filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
    const event = require(`./client/events/${file}`);
    event(client);
   
   }//for

client.login(process.env.TOKEN);
